# ZATCA QR

A Python library for generating ZATCA-compliant QR codes for Saudi Arabia invoices.

## Installation

```bash
pip install qrzatca
